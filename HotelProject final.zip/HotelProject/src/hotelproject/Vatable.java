package hotelproject;

public interface Vatable {

    public static final double VAT = 0.15;

    public abstract double calcTotal();
}
