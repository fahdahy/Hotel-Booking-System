package hotelproject;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        ArrayList<Item> roomList = new ArrayList<>();
        ArrayList<Booking> bookingList = new ArrayList<>();
        Scanner input = new Scanner(System.in);

        fillList(roomList);
        System.out.println("***** Welcome To " + Printable.HOTEL_NAME + " *****");

        int choice;

        try {
            do {
                System.out.print("\n1. Show All\n"
                        + "2. Show Rooms\n"
                        + "3. Show Suites\n"
                        + "4. Show SPA\n"
                        + "5. New Booking\n"
                        + "6. Show Booking\n"
                        + "7. Cancel Booking\n"
                        + "8. Read Bookings\n"
                        + "9. Exit\n"
                        + "-----------------\n");
                choice = input.nextInt();
                switch (choice) {
                    case 1:
                        for (Item item : roomList) {
                            System.out.println(item);
                            System.out.println("------------------------------------------------------");
                        }
                        break;

                    case 2:
                        for (Item item : roomList) {
                            if (item instanceof Room) { //to check if it is a room
                                System.out.println(item);
                                System.out.println("------------------------------------------------------");
                            }
                        }
                        break;

                    case 3:
                        for (Item item : roomList) {
                            if (item instanceof Suite) { //to check if it is a suite
                                System.out.println(item);
                                System.out.println("------------------------------------------------------");
                            }
                        }
                        break;

                    case 4:
                        System.out.println("-----------------** SPA Center **---------------------");
                        for (Item item : roomList) {
                            if (item instanceof SPA) { //to check if it is the spa
                                System.out.println(item);//toString
                                System.out.println("------------------------------------------------------");
                            }
                        }
                        break;

                    case 5:

                        System.out.print("Enter The Booking Type:\n"
                                + "1. Accommodation Booking\n"
                                + "2. SPA Booking\n"
                                + "--------------------------\n");
                        int bookingType = input.nextInt();

                        System.out.print("Enter Check In Date(YYYY-MM-DD): ");
                        input.nextLine();
                        String checkIn = input.nextLine();
                        if (!Booking.isDateValid(checkIn)) {
                            System.out.println("Invalid Date Value.");
                            break;
                        }
                        if (!Booking.isCheckInDateValid(checkIn)) {
                            System.out.println("Invalid Date Value.");
                            break;
                        }

                        Item room = null;
                        int nights = 0;
                        int hours = 0;
                        switch (bookingType) {

                            case 1:
                                System.out.print("Enter Room or Suite number: ");
                                int roomNumber = input.nextInt();

                                for (Item item : roomList) {
                                    if (item.getId() == roomNumber) {
                                        if (item instanceof SPA) {
                                            System.out.println("You can't book SPA to stay.");
                                        } else {
                                            room = item;
                                            break;
                                        }
                                    }
                                }

                                if (room == null) {
                                    System.out.println("Sorry, This Room/Suite is not found.");
                                    break;
                                }

                                
                                if (!room.isAvailable()) {
                                    System.out.println("Sorry, this Room/Suite is taken.");
                                    break;
                                }

                                System.out.print("Enter Nights: (1-30 Nights) ");
                                nights = input.nextInt();
                                if (nights < 1 || nights > Reservable.MAX_NIGHTS) {
                                    System.out.println("Invalid Nights !");
                                    break;
                                }
                                break;

                            case 2:
                                System.out.print("Enter Duration in Hours(1-3): ");
                                hours = input.nextInt();
                                if (hours < 1 || hours > Reservable.MAX_SPA_HOURS) {
                                    System.out.println("Invalid Hours !");
                                    break;
                                }
                                break;
                            default:
                                System.out.println("Invalid Option.");
                        }

                        System.out.print("Enter your id: ");
                        int id = input.nextInt();
                        System.out.print("Enter your name: ");
                        input.nextLine();
                        String name = input.nextLine();
                        System.out.print("Enter your phone: ");
                        String phone = input.nextLine();

                        Client client = new Client(id, name, phone);
                        Booking booking;
                        if (bookingType == 1) {
                            booking = new AccommodationBooking(client, checkIn, nights, room);
                        } else {
                            booking = new SpaBooking(client, checkIn, hours);
                        }

                        booking.confirm();
                        bookingList.add(booking);
                        break;

                    case 6:
                        System.out.print("Enter your booking id: ");
                        int bookingId = input.nextInt();
                        boolean isFound = false;
                        for (Booking b : bookingList) {
                            if (b.getId() == bookingId) {
                                b.print();
                                isFound = true;
                                break;
                            }
                        }
                        if (!isFound) {
                            System.out.println("Sorry, this booking not found.");
                        }
                        break;

                    case 7:
                        System.out.print("Enter your booking id: ");
                        bookingId = input.nextInt();
                        isFound = false;
                        for (Booking b : bookingList) {
                            if (b.getId() == bookingId) {
                                b.cancel();
                                isFound = true;
                                break;
                            }
                        }
                        if (!isFound) {
                            System.out.println("Sorry, this booking not found.");
                        }
                        break;

                    case 8:

                        ReadTextFile reader = new ReadTextFile();
                        reader.OpenFile("bookings.txt");
                        reader.ReadFile();
                        reader.Close();
                        break;

                    case 9:

                        WriteTextFile writer = new WriteTextFile();
                        writer.OpenFile("bookings.txt");
                        for (Booking b : bookingList) {
                            writer.Write(b);
                        }
                        writer.close();
                        System.out.println("All Bookings have been saved to bookings.txt file.");
                        System.out.println("Thank you.");
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }

            } while (choice != 9);
        } catch (InputMismatchException ex) {
            System.err.println("Invalid Input");
        }
    }

    public static void fillList(ArrayList<Item> roomList) {
        saveRooms();

        ReadBinaryFile reader = new ReadBinaryFile();
        reader.OpenFile("rooms.ser");
        ArrayList<Item> rooms = reader.readRooms();
        for (Item room : rooms) {
            roomList.add(room);
        }
        reader.Close();
    }

    public static void saveRooms() {

        Item room1 = new Room(11, "One Guest Room", 15, "Single", 1);
        Item room2 = new Room(22, "Double Bed Room", 25, "Double", 2);
        Item room3 = new Room(33, "Delux Room With Office Table", 35, "Delux", 1);

        Item jSuite = new JuniorSuite(44, "Junior Suite With See View", 40, 1, "King");
        Item rSuite1 = new RoyalSuite(55, "Royal Suite with 2 Bed Rooms", 300, 4, 2);
        Item rSuite2 = new RoyalSuite(66, "Large Royal Suite with 5 Bed Rooms", 700, 9, 5);

        Item spa = new SPA(77, "Shine SPA Center", 5, "10:00 AM - 11:59 PM", 20);

        
        
        room2.addFacility(new Facility("Coffee Maker Machine"));
        room2.addFacility(new Facility("Wifi"));
        room2.addFacility(new Facility("A.C"));
        
        room3.addFacility(new Facility("Coffee Maker Machine"));
        room3.addFacility(new Facility("A.C"));
        
        jSuite.addFacility(new Facility("Coffee Maker Machine And Free Breakfast"));
        jSuite.addFacility(new Facility("Wifi"));
        jSuite.addFacility(new Facility("A.C"));
        
        rSuite1.addFacility(new Facility("Coffee Maker Machine And Free Breakfast"));
        rSuite1.addFacility(new Facility("Wifi"));
        rSuite1.addFacility(new Facility("A.C"));
        
        rSuite2.addFacility(new Facility("Coffee Maker Machine And Free Breakfast"));
        rSuite2.addFacility(new Facility("Wifi"));
        rSuite2.addFacility(new Facility("A.C"));
        
        
        WriteBinaryFile writer = new WriteBinaryFile();
        writer.OpenFile("rooms.ser");

        writer.Write(room1);
        writer.Write(room2);
        writer.Write(room3);
        writer.Write(jSuite);
        writer.Write(rSuite1);
        writer.Write(rSuite2);
        writer.Write(spa);

        writer.Close();

    }

}
