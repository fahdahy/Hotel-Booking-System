package hotelproject;

public interface Printable {

    public static final String HOTEL_NAME = "Four Seasons Hotel";

    public abstract void print();
}
