package hotelproject;

public class JuniorSuite extends Suite {

    private String bedType; //Queen, King .....

    public JuniorSuite() {
    }

    public JuniorSuite(int id, String name, int size, int rooms, String bedType) {
        super(id, name, size, rooms);
        setBedType(bedType);
    }

    @Override
    public double calcPrice() {
        double price = 350.0;

        if (bedType.equals("King")) {
            price += 30;
        }
        return price;
    }

    public String getBedType() {
        return bedType;
    }

    public void setBedType(String bedType) {
        this.bedType = bedType;
    }

    @Override
    public String toString() {
        return String.format("%s\nBed Type: %s\nPrice Per Night: %.2f SAR", super.toString(), getBedType(), calcPrice());
    }
}
