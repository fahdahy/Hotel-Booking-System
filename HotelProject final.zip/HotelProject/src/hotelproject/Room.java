package hotelproject;

public class Room extends Item {

    private String type;
    private int beds;

    public Room() {
        this(0, "", 0, "", 0);
    }

    public Room(int id, String name, int size, String type, int beds) {
        super(id, name, size);
        setType(type);
        setBeds(beds);
    }

    @Override
    public double calcPrice() {
        double price;

        switch (type.toUpperCase()) {
            case "Single":
                price = 100;
                break;
            
            case "Double":
                price = 150;
                break;
            
            case "Delux":
                price = 200;
                break;
            
            default:
                price = 90;
        }

        if (beds > 2) {
            price += 50 * beds;
        }

        return price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getBeds() {
        return beds;
    }

    public void setBeds(int beds) {
        this.beds = beds;
    }

    @Override
    public String toString(){
        return String.format("%sRoom Type: %s\nBeds: %d\nPrice Per Night: %.2f SAR", super.toString(),getType(), getBeds(),calcPrice());
    }
}
