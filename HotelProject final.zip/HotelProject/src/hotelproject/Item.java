package hotelproject;

import java.io.Serializable;

public abstract class Item implements Reservable, Serializable {

    private final int id;
    private String description;
    private int size;
    private boolean available;

    private Facility[] facilities;
    private static final int MAX_FACILITIES = 10;//size of the array
    private int numOfFacilities;

    public Item() {
        this(0, "", 0);
    }

    public Item(int id, String description, int size) {
        this.id = id;
        setDescription(description);
        setAvailable(true);
        setSize(size);
        facilities = new Facility[MAX_FACILITIES];
    }

    @Override
    public abstract double calcPrice();

    @Override
    public void reserve() {
        setAvailable(false);
    }

    public void addFacility(Facility facility) {
        if (numOfFacilities >= MAX_FACILITIES) {
            System.out.println("Facilities is full.");
        } else {
            try {
                facilities[numOfFacilities] = facility;
                numOfFacilities++;
            } catch (ArrayIndexOutOfBoundsException e) {
                System.err.println("Invalid index.");
            }
        }
    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public Facility[] getFacilities() {
        return facilities;
    }

    public void setFacilities(Facility[] facilities) {
        this.facilities = facilities;
    }

    public int getNumOfFacilities() {
        return numOfFacilities;
    }

    public void setNumOfFacilities(int numOfFacilities) {
        this.numOfFacilities = numOfFacilities;
    }

    public String getAllFacilities() {
        String str = "";

        if (numOfFacilities == 0) {
            str = "No facilities yet.\n";
        } else {
            for (Facility facility : facilities) {
                if (facility != null) {
                    str += facility.toString();
                }
            }
        }
        return str;
    }

    @Override
    public String toString() {
        return String.format("Id: %d\nDescription: %s\nSize: %d m^2\nFacilities:\n%s", getId(), getDescription(), getSize(), getAllFacilities());
    }

}
