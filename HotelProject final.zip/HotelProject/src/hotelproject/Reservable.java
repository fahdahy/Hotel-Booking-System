package hotelproject;

public interface Reservable {

    public static final int MAX_SPA_HOURS = 3;
    public static final int MAX_NIGHTS = 30;

    public abstract double calcPrice();

    public abstract void reserve();
}
