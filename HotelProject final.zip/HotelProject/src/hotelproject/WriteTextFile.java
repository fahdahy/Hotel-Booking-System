package hotelproject;

import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.FormatterClosedException;

public class WriteTextFile {

    private Formatter output;

    public void OpenFile(String fileName) {
        try {
            output = new Formatter(fileName);

        } catch (SecurityException ex) {
            System.err.println("you can't open this file ");

        } catch (FileNotFoundException ex) {
            System.err.println("file not found ");
        }
    }

    public void Write(Booking b) {
        try {
            output.format("%s%n", b.toString());
        } catch (FormatterClosedException ex) {
            System.err.println("Formatter already closed");
        }
    }

    public void close() {
        if (output != null) {
            output.close();
        }
    }
}
