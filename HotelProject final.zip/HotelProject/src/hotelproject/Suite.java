package hotelproject;

public abstract class Suite extends Item {

    private int rooms;

    public Suite() {
        this(0, "", 0, 0);
    }

    public Suite(int id, String name, int size, int rooms) {
        super(id, name, size);
        setRooms(rooms);
    }

    @Override
    public abstract double calcPrice();

    public int getRooms() {
        return rooms;
    }

    public void setRooms(int rooms) {
        this.rooms = rooms;
    }

    @Override
    public String toString() {
        return String.format("%sRooms: %d", super.toString(), getRooms());
    }

}
