package hotelproject;

import java.io.Serializable;

public class Facility implements Serializable {

    private String name;

    public Facility() {
        this("");
    }

    public Facility(String name) {
        setName(name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return String.format("  %s\n", getName());
    }

}
