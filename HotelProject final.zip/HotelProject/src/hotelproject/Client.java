package hotelproject;

public class Client {

    private final int id;
    private String name;
    private String phone;

    public Client() {
        this(0, "", "");
    }

    public Client(int id, String name, String phone) {
        this.id = id;
        setName(name);
        setPhone(phone);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return String.format("Id: %d, Name: %s, Phone: %s", getId(), getName(), getPhone());
    }
}
