package hotelproject;

public class RoyalSuite extends Suite {

    private int bedRooms;

    public RoyalSuite() {
        this(0, "", 0, 0, 0);
    }

    public RoyalSuite(int id, String name, int size, int rooms, int bedRooms) {
        super(id, name, size, rooms);
        setBedRooms(bedRooms);
    }

    @Override
    public double calcPrice() {
        double price = 700.0;

        if (bedRooms > 1) {
            price += bedRooms * 500;
        }

        return price;
    }

    public int getBedRooms() {
        return bedRooms;
    }

    public void setBedRooms(int bedRooms) {
        this.bedRooms = bedRooms;
    }

    @Override
    public String toString() {
        return String.format("%s\nBed Rooms: %d\nPrice Per Night: %.2f SAR", super.toString(), getBedRooms(), calcPrice());
    }

}
