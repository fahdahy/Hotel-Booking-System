package hotelproject;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class ReadBinaryFile {

    private ObjectInputStream input;

    public void OpenFile(String fileName) {
        try {
            input = new ObjectInputStream(new FileInputStream(fileName));
        } catch (FileNotFoundException ex) {
            System.err.println("file not found");
        } catch (IOException ex) {
            System.err.println("io error " + ex);
        }
    }

    public ArrayList<Item> readRooms() {
        ArrayList<Item> list = new ArrayList<>();
        try {
            while (true) {
                Item unit = (Item) input.readObject();
                list.add(unit);
            }
        } catch (EOFException ex) {
        } catch (ClassNotFoundException ex) {
            System.err.println("Class Not Found");
        } catch (IOException ex) {
            System.err.println("IO Error");
        }
        return list;

    }

    public void Close() {
        if (input != null) {
            try {
                input.close();
            } catch (IOException ex) {
                System.err.println("io error" + ex);
            }
        }
    }
}
