package hotelproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ReadTextFile {

    private Scanner input;

    public void OpenFile(String fileName) {

        try {
            input = new Scanner(new File(fileName));
        } catch (FileNotFoundException ex) {
            System.err.println("File " + fileName + " not Found, create the file first.");
        }
    }

    public void ReadFile() {
        try {
            while (input.hasNextLine()) {
                String line = input.nextLine();
                System.out.println(line);
            }
        } catch (NoSuchElementException ex) {
            System.err.println("Error");
        } catch (IllegalStateException ex) {
            System.err.println("Scanner is closed ");
        } catch (NullPointerException ex) {
        }
    }

    public void Close() {
        if (input != null) {
            input.close();
        }
    }

}
