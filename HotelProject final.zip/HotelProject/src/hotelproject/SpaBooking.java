package hotelproject;


public class SpaBooking extends Booking {

    private static SPA spa = new SPA(77, "Shine SPA Center", 5, "10:00 AM - 11:59 PM", 20);
    private int duration; //in hours

    public SpaBooking() {
        this(null," ",0);
    }

    public static SPA getSpa() {
        return spa;
    }

    public static void setSpa(SPA spa) {
        SpaBooking.spa = spa;
    }


    public SpaBooking(Client client, String checkIn, int duration) {
        super(client, checkIn);
        setDuration(duration);

    }

    @Override
    public void print() {
        System.out.println("**** SPA Booking ***");
        super.print();
        System.out.println("Duration(Hours): " + getDuration());
        System.out.printf("Total Price: %.2f SAR\n", calcTotal());
                System.out.println("--------------------------------------------------");

    }

    @Override
    public double calcTotal() {

        double pricePerHour = spa.calcPrice();//polymorphic
        double total = pricePerHour * getDuration();

        //15% VAT
        total += (total * Vatable.VAT);
        return total;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return String.format("%s\nDuration: %d Hour\nTotal: %.2f SAR", super.toString(), getDuration(), calcTotal());
    }

}
