package hotelproject;

import java.time.LocalDate;

public abstract class Booking implements Printable, Vatable {

    private static int numOfBookings;
    private final int id;
    private LocalDate checkIn;
    private String status;
    private Client client;

    public Booking() {
        this(null, "");
    }

    public Booking(Client client, String checkIn) {
        id = ++numOfBookings;
        setClient(client);
        setCheckIn(checkIn);
    }

    @Override
    public void print() {
        System.out.println("--------------------------------------------------");
        System.out.println("**** " + Printable.HOTEL_NAME + " ****");
        System.out.println("Booking Id: " + getId());
        System.out.println("Booking Status: " + getStatus());
        System.out.println("Check In: " + getCheckIn());
        System.out.println("Client Info: " + getClient());
    }

    @Override
    public abstract double calcTotal();

    public void confirm() {
        setStatus("Confirmed");
        print();
        System.out.println("Your booking has been confirmed, Thank you.");

    }

    public void cancel() {
        setStatus("Cancelled");
        System.out.println("Your booking has been cancelled, Thank you.");
    }

    public static int getNumOfBookings() {
        return numOfBookings;
    }

    public static void setNumOfBookings(int numOfBookings) {
        Booking.numOfBookings = numOfBookings;
    }

    public int getId() {
        return id;
    }

    public LocalDate getCheckIn() {
        return checkIn;
    }

    //to check and validate date
    public static boolean isDateValid(String str) {

        try {
            LocalDate.parse(str);
            return true;
        } catch (Exception e) {
            System.err.println("Invalid Date Value.");
            return false;
        }
    }

    public static boolean isCheckInDateValid(String str) {
        try {
            LocalDate checkInDate = LocalDate.parse(str);
            LocalDate todayDate = LocalDate.now();
            if (checkInDate.isBefore(todayDate)) {
                return false;
            }
        } catch (Exception e) {
            System.err.println("Invalid Date Value.");
            return false;
        }
        return true;
    }

    public void setCheckIn(String checkIn) {
        try {
            this.checkIn = LocalDate.parse(checkIn);
        } catch (Exception ex) {
            System.out.println("Invalid date.");
        }
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    @Override
    public String toString() {
        return String.format("Booking Type: %s\nBooking Id: %d\nCheck In: %s\nStatus: %s\nClient: %s", getClass().getSimpleName(), getId(), getCheckIn(), getStatus(), getClient());
    }
}
