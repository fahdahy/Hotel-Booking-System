package hotelproject;

import java.time.LocalDate;

public class AccommodationBooking extends Booking {

    private int nights;
    private Item unit; //Room or Suite

    public AccommodationBooking() {
        this(null, "", 0, null);
    }

    public AccommodationBooking(Client client, String checkIn, int nights, Item unit) {
        super(client, checkIn);
        setNights(nights);
        setUnit(unit);
    }

    @Override
    public void print() {
        System.out.println("**** Accommodation Booking ***");
        super.print();
        System.out.println("Check Out: " + getCheckOut());
        System.out.println("Nights: " + getNights());
        System.out.println("Unit: " + getUnit());
        System.out.printf("Total Price: %.2f SAR\n", calcTotal());
        System.out.println("--------------------------------------------------");

    }

    @Override
    public double calcTotal() {

        double pricePerNight = unit.calcPrice(); //polymorphic
        double total = pricePerNight * getNights();

        //15% VAT
        total += (total * Vatable.VAT);
        return total;
    }

    public LocalDate getCheckOut() {
        return getCheckIn().plusDays(nights);
    }

    public int getNights() {
        return nights;
    }

    public void setNights(int nights) {
        this.nights = nights;
    }

    public Item getUnit() {
        return unit;
    }

    public void setUnit(Item unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return String.format("%s\nCheck Out: %s\nNights: %d\nTotal: %.2f SAR", super.toString(), getCheckOut(), getNights(), calcTotal());
    }

}
