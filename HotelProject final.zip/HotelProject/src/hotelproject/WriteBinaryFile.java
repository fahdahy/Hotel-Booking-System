package hotelproject;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class WriteBinaryFile {

    private ObjectOutputStream output;

    public void OpenFile(String fileName) {
        try {
            output = new ObjectOutputStream(new FileOutputStream(fileName));
        } catch (FileNotFoundException ex) {
            System.err.println("File not found");
        } catch (IOException ex) {
            System.err.println("io error " + ex);
        }
    }

    public void Write(Item item) {
        try {
            output.writeObject(item);
        } catch (IOException ex) {
            System.err.println("IO error");
        }

    }

    public void Close() {
        if (output != null) {
            try {
                output.close();
            } catch (IOException ex) {
                System.out.println("IO error" + ex);
            }
        }
    }

}
