package hotelproject;

public class SPA extends Item {

    private String openingTime;
    private int availableSeats;

    public SPA() {
        this(0, "", 0, "", 0);
    }

    public SPA(int id, String name, int size, String openingType, int availableSeats) {
        super(id, name, size);
        setOpeningTime(openingType);
        setAvailableSeats(availableSeats);
    }

    @Override
    public double calcPrice() {
        return 100; //per hour
    }

    @Override
    public void reserve() {
        int seats = getAvailableSeats();
        setAvailableSeats(seats - 1);

    }

    public String getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(String openingTime) {
        this.openingTime = openingTime;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    @Override
    public String toString() {
        return String.format("%s\nOpening Time:%s\nSeats Available: %d\nPrice Per Hour: %.2f SAR", super.toString(), getOpeningTime(), getAvailableSeats(), calcPrice());
    }
}
